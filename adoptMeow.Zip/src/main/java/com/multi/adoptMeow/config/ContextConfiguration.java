package com.multi.adoptMeow.config;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@ComponentScan(basePackages = "com.multi.adoptMeow")
@Configuration
public class ContextConfiguration {
}
